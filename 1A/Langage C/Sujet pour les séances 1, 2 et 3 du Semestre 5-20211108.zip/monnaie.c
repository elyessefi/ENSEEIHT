#include <stdlib.h> 
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

// Definition du type monnaie
// TODO 

/**
 * \brief Initialiser une monnaie 
 * \param[]
 * \pre 
 * // TODO
 */ 
void initialiser(){
    // TODO
}


/**
 * \brief Ajouter une monnaie m2 à une monnaie m1 
 * \param[]
 * // TODO
 */ 
bool ajouter(){
    // TODO
}


/**
 * \brief Tester Initialiser 
 * \param[]
 * // TODO
 */ 
void tester_initialiser(){
    // TODO
}

/**
 * \brief Tester Ajouter 
 * \param[]
 * // TODO
 */ 
void tester_ajouter(){
    // TODO
}



int main(void){
    // Un tableau de 5 monnaies
    // TODO

    //Initialiser les monnaies
    // TODO
 
    // Afficher la somme des toutes les monnaies qui sont dans une devise entrée par l'utilisateur.
    // TODO

    return EXIT_SUCCESS;
}
