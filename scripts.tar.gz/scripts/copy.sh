
hdfs dfs -mkdir /input
hdfs dfs -put /tmp/data.txt /input

