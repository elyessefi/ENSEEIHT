

stop-slaves.sh
stop-master.sh

stop-dfs.sh


