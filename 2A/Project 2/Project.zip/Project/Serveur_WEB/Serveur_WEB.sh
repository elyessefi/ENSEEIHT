#ip route add 120.0.50.0/23 via 120.0.54.2

#auto eth1
#allow-hotplug eth1
#iface eth0 inet dhcp
service apache2 start