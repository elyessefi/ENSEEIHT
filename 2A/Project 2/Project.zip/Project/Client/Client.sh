#!/bin/bash

#ip link set dev eth0 up
#ip addr add 192.168.1.2/24 dev eth0

#ip link set dev eth1 up
#ip addr add 10.0.0.4/24 dev eth1

#ip route add 120.0.56.0/23 via 192.168.1.2
#ip route add 192.168.1.0/24 via 192.168.1.1
#ip route add 120.0.48.0/23 via 192.168.1.2
#ip route add 120.0.50.0/23 via 192.168.1.2
#ip route add 120.0.54.0/23 via 192.168.1.2
#ls -l