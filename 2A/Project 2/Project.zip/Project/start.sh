#!/bin/bash
docker exec Routeur_SiteP //Routeur_SiteP.sh